/**
 * Minimal logging wrapper. Swap the internals for Winston/Pino later
 * without touching any call sites — everything imports `logger` from here.
 */
const timestamp = () => new Date().toISOString()

export const logger = {
  info: (...args) => console.log(`[INFO] ${timestamp()} -`, ...args),
  warn: (...args) => console.warn(`[WARN] ${timestamp()} -`, ...args),
  error: (...args) => console.error(`[ERROR] ${timestamp()} -`, ...args),
  debug: (...args) => {
    if (process.env.NODE_ENV !== 'production') {
      console.debug(`[DEBUG] ${timestamp()} -`, ...args)
    }
  },
}

export default logger
