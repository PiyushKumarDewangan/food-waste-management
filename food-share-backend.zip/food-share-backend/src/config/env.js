import dotenv from 'dotenv'
import path from 'path'

// Always resolve .env from the project root (process.cwd()), regardless of
// how deeply this file is imported from within src/. This is why .env lives
// at the project root and NOT inside src/.
dotenv.config({ path: path.resolve(process.cwd(), '.env') })

function required(key) {
  const value = process.env[key]
  if (!value) {
    // Fail fast and loud at boot time rather than deep inside a request.
    throw new Error(`Missing required environment variable: ${key}`)
  }
  return value
}


//1. here it is named export
// for this import { env } from './config/env.js'
export const env = {
  NODE_ENV: process.env.NODE_ENV || 'development',
  PORT: Number(process.env.PORT) || 5000,
//2. Number is a func. to convert string to no.

  MONGODB_URI: required('MONGODB_URI'),

  JWT_ACCESS_SECRET: required('JWT_ACCESS_SECRET'),
  JWT_REFRESH_SECRET: required('JWT_REFRESH_SECRET'),
  JWT_ACCESS_EXPIRY: process.env.JWT_ACCESS_EXPIRY || '15m',
  JWT_REFRESH_EXPIRY: process.env.JWT_REFRESH_EXPIRY || '7d',

  CORS_ORIGIN: process.env.CORS_ORIGIN || 'http://localhost:5173',
  FRONTEND_URL: process.env.FRONTEND_URL || process.env.CORS_ORIGIN || 'http://localhost:5173',
  REFRESH_COOKIE_NAME: process.env.REFRESH_COOKIE_NAME || 'fb_refresh_token',

  MAX_UPLOAD_SIZE_MB: Number(process.env.MAX_UPLOAD_SIZE_MB) || 5,

  GOOGLE_CLIENT_ID: process.env.GOOGLE_CLIENT_ID || '',

  // SMTP (email sending) — optional in development; if unset, sendEmail.js
  // logs emails to the console instead of failing the request.
  SMTP_HOST: process.env.SMTP_HOST || '',
  SMTP_PORT: Number(process.env.SMTP_PORT) || 587,
  SMTP_USER: process.env.SMTP_USER || '',
  SMTP_PASS: process.env.SMTP_PASS || '',
  SMTP_FROM: process.env.SMTP_FROM || '"FoodBridge" <no-reply@foodbridge.org>',
}

export default env
